package com.haringeymobile.ukweather.data.objects;

import com.google.gson.annotations.SerializedName;

public class Rain {

    @SerializedName("3h")
    private int precipitationVolumePer3HhoursInMm;
}
