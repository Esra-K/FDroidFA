package com.corvettecole.gotosleep.utilities;

import androidx.lifecycle.ViewModel;

public class PreferencesViewModel extends ViewModel {
    
}
